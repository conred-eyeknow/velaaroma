<!--Core js-->
<script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script src="../resources/js/bootstrap.min.js"></script>
<script src="../resources/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="../resources/js/jquery.scrollTo.min.js"></script>
<script src="../resources/js/jquery.slimscroll.js"></script>
<script src="../resources/js/jquery.nicescroll.js"></script>
<script src="../resources/js/notifications.js"></script>

<!-- canvasjs -->
<script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>

<!--  boostrap select --> 
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
 
<!--common script init for all pages-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/script.js/2.5.9/script.min.js"></script>
