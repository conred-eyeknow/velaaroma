<?php 

$__URL_API__ = "http://ec2-3-131-17-88.us-east-2.compute.amazonaws.com/";
$__URL_FAVICON__ = $__URL_EYEKNOW__ . "resources/images/favicon.ico"; 
$__RESOURCES__ =  "./resources/";
$__IMAGES__ = $__RESOURCES__ . "images/";
$__LOGO__ = $__IMAGES__ . "logo.png";
$__LOADING__ = $__IMAGES__ . "loading.gif";  
